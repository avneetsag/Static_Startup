const mongoose = require('mongoose');
module.exports = mongoose.model('fridge', new mongoose.Schema({
    name: String,
    user: String
   }));
